export const environment = {
  production: true,
  apiKey: '86c19702c9e24af9888bcb56c23e1ee5'
};

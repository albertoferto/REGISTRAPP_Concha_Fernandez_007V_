import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modificar-asistencia',
  templateUrl: './modificar-asistencia.page.html',
  styleUrls: ['./modificar-asistencia.page.scss'],
})
export class ModificarAsistenciaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generar',
  templateUrl: './generar.page.html',
  styleUrls: ['./generar.page.scss'],
})
export class GenerarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-escanear',
  templateUrl: './escanear.page.html',
  styleUrls: ['./escanear.page.scss'],
})
export class EscanearPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

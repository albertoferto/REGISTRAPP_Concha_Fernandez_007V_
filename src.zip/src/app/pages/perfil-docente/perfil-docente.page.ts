import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perfil-docente',
  templateUrl: './perfil-docente.page.html',
  styleUrls: ['./perfil-docente.page.scss'],
})
export class PerfilDocentePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contra-cambiada',
  templateUrl: './contra-cambiada.page.html',
  styleUrls: ['./contra-cambiada.page.scss'],
})
export class ContraCambiadaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

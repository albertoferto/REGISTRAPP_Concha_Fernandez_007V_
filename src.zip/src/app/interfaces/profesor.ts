interface Profesor {
    icon:string;
  name:string;
  redirecTo:string;
}